import { useState, type FormEvent } from 'react';
import { MAX_SITE_RULES } from '../shared/defaults';
import { hostnameFromUserInput } from '../shared/hostname';
import { AppearanceControls, Logo, StatusLine, Switch } from '../ui/components';
import { useSettings } from '../ui/hooks';

export function Options() {
  const { settings, notice, change, reset } = useSettings();
  const [input, setInput] = useState('');
  const [inputError, setInputError] = useState('');
  const [confirmReset, setConfirmReset] = useState(false);

  const excluded = Object.entries(settings.siteRules).filter(([, m]) => m === 'off').map(([h]) => h).sort();
  const forced = Object.entries(settings.siteRules).filter(([, m]) => m === 'on').map(([h]) => h).sort();

  const addExcluded = (e: FormEvent) => {
    e.preventDefault();
    const host = hostnameFromUserInput(input);
    if (!host) { setInputError('Enter a website address such as example.com.'); return; }
    if (Object.keys(settings.siteRules).length >= MAX_SITE_RULES && !(host in settings.siteRules)) { setInputError('Too many site rules.'); return; }
    setInputError('');
    setInput('');
    void change((s) => ({ ...s, siteRules: { ...s.siteRules, [host]: 'off' } }), `${host} is now excluded.`);
  };
  const removeRule = (host: string) => void change((s) => { const r = { ...s.siteRules }; delete r[host]; return { ...s, siteRules: r }; }, `${host} was removed from your site rules.`);

  return (
    <main className="stack" style={{ maxWidth: 560, margin: '0 auto', padding: 24, gap: 20 }}>
      <header className="brand"><Logo /><h1>NightLens settings</h1></header>

      <section className="card stack" aria-labelledby="general">
        <h2 id="general">General</h2>
        <div className="row"><span>Dark mode on all sites</span>
          <Switch label="Dark mode (all sites)" checked={settings.enabled} onChange={(enabled) => void change((s) => ({ ...s, enabled }), enabled ? 'Dark mode turned on.' : 'Dark mode turned off everywhere.')} /></div>
        <AppearanceControls settings={settings} onChange={(u, m) => void change(u, m)} showSepia />
        <p className="muted" style={{ margin: 0 }}>Text contrast never drops below WCAG AA (4.5:1; 7:1 in High contrast mode) where that is achievable, whatever these sliders say.</p>
      </section>

      <section className="card stack" aria-labelledby="sites">
        <h2 id="sites">Sites</h2>
        <p className="muted" style={{ margin: 0 }}>Rules match the exact hostname. <code>example.com</code> does not cover <code>www.example.com</code> or <code>docs.example.com</code>; add each one you want. Ports, schemes and paths are ignored.</p>
        <form className="row" onSubmit={addExcluded} noValidate>
          <div className="field" style={{ flex: 1 }}>
            <label htmlFor="exclude-input">Exclude a website</label>
            <input id="exclude-input" type="text" value={input} placeholder="example.com" aria-invalid={inputError !== ''} aria-describedby="exclude-error" onChange={(e) => setInput(e.target.value)} />
          </div>
          <button type="submit" className="btn primary" style={{ alignSelf: 'flex-end' }}>Add</button>
        </form>
        <div id="exclude-error" className="status error" role="alert">{inputError}</div>
        <h3 style={{ fontSize: 14 }}>Excluded sites</h3>
        {excluded.length === 0 ? <p className="muted" style={{ margin: 0 }}>No excluded sites. Use the toolbar popup or the form above to add one.</p> : (
          <ul className="sites" aria-label="Excluded sites">{excluded.map((h) => <li key={h}><span>{h}</span><button type="button" className="btn" aria-label={`Remove ${h} from excluded sites`} onClick={() => removeRule(h)}>Remove</button></li>)}</ul>
        )}
        <h3 style={{ fontSize: 14 }}>Forced on</h3>
        {forced.length === 0 ? <p className="muted" style={{ margin: 0 }}>None. Sites that already look dark are left alone unless you force them on from the popup.</p> : (
          <ul className="sites" aria-label="Sites forced on">{forced.map((h) => <li key={h}><span>{h}</span><button type="button" className="btn" aria-label={`Remove ${h} from forced sites`} onClick={() => removeRule(h)}>Remove</button></li>)}</ul>
        )}
      </section>

      <section className="card stack" aria-labelledby="privacy">
        <h2 id="privacy">Your data</h2>
        <p style={{ margin: 0 }}>NightLens stores only these settings, in this browser’s local extension storage: on/off, theme, brightness, contrast, warmth, and the hostnames you excluded or forced on. It does not read or record your browsing history, send anything to a server, or use analytics.</p>
      </section>

      <StatusLine notice={notice} />
      <div>
        {!confirmReset ? <button type="button" className="btn danger" onClick={() => setConfirmReset(true)}>Reset all settings…</button> : (
          <span className="row" style={{ justifyContent: 'flex-start' }} role="group" aria-label="Confirm reset">
            <span>This also clears all site rules. Continue?</span>
            <button type="button" className="btn" onClick={() => setConfirmReset(false)}>Cancel</button>
            <button type="button" className="btn danger" onClick={() => { setConfirmReset(false); void reset(); }}>Reset everything</button>
          </span>
        )}
      </div>
    </main>
  );
}
