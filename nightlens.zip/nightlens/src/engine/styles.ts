import { toHex } from './color';
import type { ThemeTokens } from './palette';

const hex = (c: Parameters<typeof toHex>[0]): string => `#${toHex(c)}`;

/**
 * Static part of the theme. Per-element colours are added as generated attribute rules by the engine.
 * !important is used so the theme wins over author styles; the engine records every element's
 * original colours before applying anything, and removing the <style> elements restores the page.
 */
export function buildBaseCss(t: ThemeTokens): string {
  const c = t.colors;
  const media = t.mediaBrightness < 1 ? `:where(img,video,picture){filter:brightness(${t.mediaBrightness})}` : '';
  return [
    `:root{color-scheme:dark !important;--nl-bg:${hex(c.bg)};--nl-bg-raised:${hex(c.bgRaised)};--nl-text:${hex(c.text)};--nl-muted:${hex(c.textMuted)};--nl-link:${hex(c.link)};--nl-visited:${hex(c.linkVisited)};--nl-border:${hex(c.border)};--nl-focus:${hex(c.focus)};--nl-sel-bg:${hex(c.selectionBg)};--nl-sel-fg:${hex(c.selectionText)}}`,
    // Early-paint guard only: the engine sets data-nl-ready on <html> right before it reads computed styles,
    // so this rule can never contaminate the "original" colours it records.
    'html:not([data-nl-ready]){background-color:var(--nl-bg) !important;color:var(--nl-text) !important}',
    'a[data-nl-link]:visited{color:var(--nl-visited) !important}',
    '::placeholder{color:var(--nl-muted) !important;opacity:1 !important}',
    '::selection{background-color:var(--nl-sel-bg);color:var(--nl-sel-fg)}',
    ':where(a,button,input,select,textarea,summary,[tabindex]):focus-visible{outline:2px solid var(--nl-focus);outline-offset:2px}',
    media,
  ].filter(Boolean).join('\n');
}
