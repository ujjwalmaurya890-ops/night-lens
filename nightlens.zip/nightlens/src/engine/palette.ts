import { LIMITS } from '../shared/defaults';
import type { Settings } from '../shared/types';
import { clamp, ensureContrast, hslToRgb, rgbToHsl, type RGB } from './color';

type Preset = 'balanced' | 'highContrast' | 'dim';

interface PresetSpec {
  bgL: number; bgMidL: number; textL: number; mutedL: number; hue: number; sat: number;
  minText: number; minBorder: number; mediaBrightness: number;
}

const PRESETS: Record<Preset, PresetSpec> = {
  balanced: { bgL: 0.115, bgMidL: 0.34, textL: 0.9, mutedL: 0.68, hue: 225, sat: 0.08, minText: 4.5, minBorder: 1.5, mediaBrightness: 1 },
  highContrast: { bgL: 0.04, bgMidL: 0.22, textL: 1, mutedL: 0.86, hue: 225, sat: 0.04, minText: 7, minBorder: 3, mediaBrightness: 1 },
  dim: { bgL: 0.17, bgMidL: 0.38, textL: 0.8, mutedL: 0.64, hue: 225, sat: 0.07, minText: 4.5, minBorder: 1.5, mediaBrightness: 0.88 },
};

const SEPIA_HUE = 35;
const RAISED_OFFSET = 0.045;
const BORDER_OFFSET = 0.14;
const MIN_FOCUS_CONTRAST = 3; // WCAG 1.4.11 non-text contrast
const MIN_DISABLED_CONTRAST = 3;
const MIN_CONTROL_BORDER_CONTRAST = 3;

export interface ThemeTokens {
  preset: Preset;
  minTextContrast: number;
  minBorderContrast: number;
  minControlBorderContrast: number;
  minDisabledContrast: number;
  neutralHue: number;
  neutralSat: number;
  /** Lightness (HSL) that a pure-white background maps to. */
  bgL: number;
  /** Lightness that a mid-tone (50%) background maps to; also the ceiling for already-dark backgrounds. */
  bgMidL: number;
  textL: number;
  mutedL: number;
  mediaBrightness: number;
  colors: Record<'bg' | 'bgRaised' | 'text' | 'textMuted' | 'link' | 'linkVisited' | 'border' | 'focus' | 'selectionBg' | 'selectionText', RGB>;
}

const SEPIA_SAT_BOOST = 0.2;

/**
 * Tint for neutral colours. Interpolating hue directly would pass through magenta/green on the way from
 * cool grey to warm, so the cool and warm tints are blended in RGB and the resulting hue/saturation used.
 */
function neutralTint(baseHue: number, baseSat: number, warmth: number): { hue: number; sat: number } {
  const cool = hslToRgb({ h: baseHue, s: baseSat, l: 0.5 });
  const warm = hslToRgb({ h: SEPIA_HUE, s: baseSat + SEPIA_SAT_BOOST, l: 0.5 });
  const mix = { r: cool.r + (warm.r - cool.r) * warmth, g: cool.g + (warm.g - cool.g) * warmth, b: cool.b + (warm.b - cool.b) * warmth };
  const { h, s } = rgbToHsl(mix);
  return warmth === 0 ? { hue: baseHue, sat: baseSat } : { hue: h, sat: s };
}

export function resolvePreset(theme: Settings['theme']): Preset {
  return theme === 'system' ? 'balanced' : theme;
}

export function buildTokens(s: Pick<Settings, 'theme' | 'brightness' | 'contrast' | 'sepia'>): ThemeTokens {
  const preset = resolvePreset(s.theme);
  const p = PRESETS[preset];
  const f = clamp(s.brightness, LIMITS.brightness.min, LIMITS.brightness.max) / 100;
  const c = clamp(s.contrast, LIMITS.contrast.min, LIMITS.contrast.max) / 100;
  const sep = clamp(s.sepia, LIMITS.sepia.min, LIMITS.sepia.max) / 100;

  const bgL = clamp(p.bgL * f, 0.02, 0.3);
  const bgMidL = clamp(p.bgMidL * f, bgL + 0.08, 0.5);
  const textTarget = clamp(p.textL + (f - 1) * 0.1, 0.7, 1);
  const mutedTarget = clamp(p.mutedL + (f - 1) * 0.1, 0.55, 0.95);
  const textL = clamp(bgL + (textTarget - bgL) * c, 0.6, 1);
  const mutedL = Math.min(clamp(bgL + (mutedTarget - bgL) * c, 0.5, 1), textL);
  const { hue, sat } = neutralTint(p.hue, p.sat, sep);

  const bg = hslToRgb({ h: hue, s: sat, l: bgL });
  const bgRaised = hslToRgb({ h: hue, s: sat, l: bgL + RAISED_OFFSET });
  // Text tokens are validated against the lighter surface, which is the stricter case.
  const text = ensureContrast(hslToRgb({ h: hue, s: sat * 0.6, l: textL }), bgRaised, p.minText);
  const textMuted = ensureContrast(hslToRgb({ h: hue, s: sat * 0.6, l: mutedL }), bgRaised, p.minText);
  const link = ensureContrast(hslToRgb({ h: 212, s: 0.95, l: 0.72 }), bgRaised, p.minText);
  const linkVisited = ensureContrast(hslToRgb({ h: 268, s: 0.75, l: 0.78 }), bgRaised, p.minText);
  const border = ensureContrast(hslToRgb({ h: hue, s: sat, l: bgL + BORDER_OFFSET }), bgRaised, p.minBorder);
  const focus = ensureContrast(hslToRgb({ h: 45, s: 0.95, l: 0.62 }), bgRaised, MIN_FOCUS_CONTRAST);
  const selectionBg = hslToRgb({ h: 212, s: 0.7, l: 0.35 });
  const selectionText = ensureContrast(text, selectionBg, 4.5);

  return {
    preset,
    minTextContrast: p.minText,
    minBorderContrast: p.minBorder,
    minControlBorderContrast: MIN_CONTROL_BORDER_CONTRAST,
    minDisabledContrast: MIN_DISABLED_CONTRAST,
    neutralHue: hue, neutralSat: sat, bgL, bgMidL, textL, mutedL,
    mediaBrightness: p.mediaBrightness,
    colors: { bg, bgRaised, text, textMuted, link, linkVisited, border, focus, selectionBg, selectionText },
  };
}
