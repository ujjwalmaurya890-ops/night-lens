import { handleCommand, handleInstalled, handleStartup, updateBadge } from './handlers';
import { subscribeToSettings } from '../shared/storage';

// Listeners must be registered synchronously at the top level of a service worker.
chrome.commands.onCommand.addListener((command) => { void handleCommand(command); });
chrome.runtime.onInstalled.addListener(() => { void handleInstalled(); });
chrome.runtime.onStartup.addListener(() => { void handleStartup(); });
subscribeToSettings((s) => { void updateBadge(s); });
