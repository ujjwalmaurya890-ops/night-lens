import { STORAGE_KEY } from '../shared/defaults';
import { loadSettings, resetSettings, updateSettings } from '../shared/storage';
import type { Settings } from '../shared/types';

export const TOGGLE_COMMAND = 'toggle-nightlens';
const BADGE_COLOR = '#5f6368';

export async function updateBadge(settings: Settings): Promise<void> {
  await chrome.action.setBadgeText({ text: settings.enabled ? '' : 'OFF' });
  await chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR });
}

export async function handleCommand(command: string): Promise<void> {
  if (command !== TOGGLE_COMMAND) return;
  const next = await updateSettings((s) => ({ ...s, enabled: !s.enabled }));
  await updateBadge(next);
}

export async function handleInstalled(): Promise<void> {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  const settings = stored[STORAGE_KEY] === undefined ? await resetSettings() : await loadSettings();
  await updateBadge(settings);
}

export async function handleStartup(): Promise<void> {
  await updateBadge(await loadSettings());
}
