import { useState } from 'react';
import type { SiteStatus } from '../shared/types';
import { AppearanceControls, Logo, StatusLine, Switch } from '../ui/components';
import { useSettings, usePageStatus } from '../ui/hooks';

const STATUS_TEXT: Record<SiteStatus, string> = {
  active: '● Dark mode is active on this site.',
  'globally-off': '○ NightLens is turned off everywhere.',
  excluded: '○ This site is excluded.',
  'native-dark': '◐ This site already looks dark, so NightLens left it alone.',
  'waiting-for-system': '○ Waiting for your system to use dark appearance.',
};

export function App() {
  const { settings, ready, notice, change, reset } = useSettings();
  const page = usePageStatus();
  const [confirmReset, setConfirmReset] = useState(false);

  const host = page.state === 'ready' ? page.hostname : null;
  const siteControlsAvailable = page.state === 'ready' && host !== null;
  const siteOn = page.state === 'ready' ? page.siteMode !== 'off' : false;

  const setSiteMode = (mode: 'on' | 'off' | null) => {
    if (!host) return;
    const text = mode === 'off' ? `${host} is now excluded.` : mode === 'on' ? `Dark mode is forced on for ${host}.` : `${host} is back on automatic.`;
    void change((s) => {
      const rules = { ...s.siteRules };
      if (mode === null) delete rules[host]; else rules[host] = mode;
      return { ...s, siteRules: rules };
    }, text);
  };

  return (
    <main className="stack" style={{ width: 340, padding: 14 }} aria-busy={!ready}>
      <header className="row">
        <h1 className="brand"><Logo />NightLens</h1>
        <div className="row" style={{ gap: 8 }}>
          <span id="global-label">Dark mode</span>
          <Switch label="Dark mode (all sites)" checked={settings.enabled} onChange={(enabled) => void change((s) => ({ ...s, enabled }), enabled ? 'Dark mode turned on.' : 'Dark mode turned off everywhere.')} />
        </div>
      </header>

      <section className="card stack" aria-labelledby="site-heading">
        <h2 id="site-heading" style={{ fontSize: 13 }} className="muted">Current website</h2>
        {page.state === 'loading' && <p className="muted" style={{ margin: 0 }}>Checking this page…</p>}
        {page.state === 'unsupported' && (
          <p className="muted" style={{ margin: 0 }}>
            NightLens can’t run on this page. Browser pages, the Chrome Web Store, local files and PDF viewers are not supported. If you just installed or updated NightLens, reload the tab.
          </p>
        )}
        {page.state === 'ready' && (
          <>
            <div className="row">
              <strong style={{ overflowWrap: 'anywhere' }}>{host ?? 'Unknown site'}</strong>
              <Switch label={`Dark mode on ${host ?? 'this site'}`} checked={siteOn} disabled={!siteControlsAvailable || !settings.enabled} onChange={(on) => setSiteMode(on ? null : 'off')} />
            </div>
            <div className="badge" id="site-status">{STATUS_TEXT[page.status]}</div>
            {page.status === 'native-dark' && <button type="button" className="btn" onClick={() => setSiteMode('on')}>Force dark mode on this site</button>}
            {page.siteMode === 'on' && <button type="button" className="link" onClick={() => setSiteMode(null)}>Back to automatic for this site</button>}
          </>
        )}
      </section>

      <AppearanceControls settings={settings} onChange={(u, m) => void change(u, m)} showSepia={false} />

      <StatusLine notice={notice} />

      <footer className="row">
        <button type="button" className="link" onClick={() => void chrome.runtime.openOptionsPage()}>Settings</button>
        {!confirmReset ? (
          <button type="button" className="btn" onClick={() => setConfirmReset(true)}>Reset…</button>
        ) : (
          <span className="row" style={{ gap: 6 }} role="group" aria-label="Confirm reset">
            <span className="muted">Reset everything?</span>
            <button type="button" className="btn" onClick={() => setConfirmReset(false)}>Cancel</button>
            <button type="button" className="btn danger" onClick={() => { setConfirmReset(false); void reset(); }}>Reset</button>
          </span>
        )}
      </footer>
    </main>
  );
}
