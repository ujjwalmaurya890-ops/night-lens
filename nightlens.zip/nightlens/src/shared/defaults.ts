import type { Settings } from './types';

export const STORAGE_KEY = 'nightlens:settings';
export const MAX_SITE_RULES = 2000;

export const LIMITS = {
  brightness: { min: 60, max: 120, step: 5, default: 100 },
  contrast: { min: 70, max: 140, step: 5, default: 100 },
  sepia: { min: 0, max: 60, step: 5, default: 0 },
} as const;

export function cloneDefaults(): Settings {
  return {
    schemaVersion: 1,
    enabled: true,
    theme: 'balanced',
    brightness: LIMITS.brightness.default,
    contrast: LIMITS.contrast.default,
    sepia: LIMITS.sepia.default,
    siteRules: {},
  };
}
