import { LIMITS, MAX_SITE_RULES, STORAGE_KEY, cloneDefaults } from './defaults';
import { normalizeHostname } from './hostname';
import { SITE_MODES, THEME_IDS, type Settings, type SiteMode, type SiteRules, type ThemeId } from './types';

function clampPercent(value: unknown, limit: { min: number; max: number }, fallback: number): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return fallback;
  return Math.min(limit.max, Math.max(limit.min, Math.round(value)));
}

function sanitizeSiteRules(raw: unknown): SiteRules {
  const out: SiteRules = {};
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) return out;
  let count = 0;
  for (const [key, value] of Object.entries(raw)) {
    if (count >= MAX_SITE_RULES) break;
    const host = normalizeHostname(key);
    if (host && (SITE_MODES as readonly unknown[]).includes(value)) {
      out[host] = value as SiteMode;
      count++;
    }
  }
  return out;
}

/** Never throws: anything invalid or missing falls back to the default for that field. */
export function sanitizeSettings(raw: unknown): Settings {
  const d = cloneDefaults();
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) return d;
  const r = raw as Record<string, unknown>;
  return {
    schemaVersion: 1,
    enabled: typeof r.enabled === 'boolean' ? r.enabled : d.enabled,
    theme: (THEME_IDS as readonly unknown[]).includes(r.theme) ? (r.theme as ThemeId) : d.theme,
    brightness: clampPercent(r.brightness, LIMITS.brightness, d.brightness),
    contrast: clampPercent(r.contrast, LIMITS.contrast, d.contrast),
    sepia: clampPercent(r.sepia, LIMITS.sepia, d.sepia),
    siteRules: sanitizeSiteRules(r.siteRules),
  };
}

export async function loadSettings(): Promise<Settings> {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    return sanitizeSettings(result[STORAGE_KEY]);
  } catch (error) {
    console.warn('[NightLens] Could not read settings; using defaults.', error);
    return cloneDefaults();
  }
}

/** Read-modify-write. Rejects if storage fails so the UI can show a real error. */
export async function updateSettings(updater: (current: Settings) => Settings): Promise<Settings> {
  const next = sanitizeSettings(updater(await loadSettings()));
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  return next;
}

export async function resetSettings(): Promise<Settings> {
  const next = cloneDefaults();
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  return next;
}

export function subscribeToSettings(callback: (settings: Settings) => void): () => void {
  const listener = (changes: Record<string, chrome.storage.StorageChange>, area: string) => {
    if (area !== 'local' || !(STORAGE_KEY in changes)) return;
    callback(sanitizeSettings(changes[STORAGE_KEY]?.newValue));
  };
  chrome.storage.onChanged.addListener(listener);
  return () => chrome.storage.onChanged.removeListener(listener);
}
