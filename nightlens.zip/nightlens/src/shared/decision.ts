import { getSiteMode } from './hostname';
import type { Settings, SiteMode, SiteStatus } from './types';

export type Decision =
  | { active: true; forceNative: boolean; siteMode: SiteMode | null }
  | { active: false; status: Exclude<SiteStatus, 'active' | 'native-dark'>; siteMode: SiteMode | null };

/** Pure decision: should the engine run on this site right now? */
export function decide(settings: Settings, hostname: string | null, systemPrefersDark: boolean): Decision {
  const siteMode = getSiteMode(settings.siteRules, hostname) ?? null;
  if (!settings.enabled) return { active: false, status: 'globally-off', siteMode };
  if (siteMode === 'off') return { active: false, status: 'excluded', siteMode };
  if (settings.theme === 'system' && !systemPrefersDark) return { active: false, status: 'waiting-for-system', siteMode };
  return { active: true, forceNative: siteMode === 'on', siteMode };
}
