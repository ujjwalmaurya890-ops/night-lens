export const THEME_IDS = ['balanced', 'highContrast', 'dim', 'system'] as const;
export type ThemeId = (typeof THEME_IDS)[number];

export const SITE_MODES = ['on', 'off'] as const;
/** 'off' = excluded; 'on' = forced even if the site looks natively dark. Absent = automatic. */
export type SiteMode = (typeof SITE_MODES)[number];
export type SiteRules = Record<string, SiteMode>;

export interface Settings {
  schemaVersion: 1;
  enabled: boolean;
  theme: ThemeId;
  /** Percent, see LIMITS. */
  brightness: number;
  contrast: number;
  sepia: number;
  siteRules: SiteRules;
}

export const SITE_STATUSES = ['active', 'globally-off', 'excluded', 'native-dark', 'waiting-for-system'] as const;
export type SiteStatus = (typeof SITE_STATUSES)[number];
