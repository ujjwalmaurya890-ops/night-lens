import { useEffect, useState } from 'react';
import { LIMITS } from '../shared/defaults';
import { THEME_IDS, type Settings, type ThemeId } from '../shared/types';

export const THEME_LABELS: Record<ThemeId, string> = {
  balanced: 'Balanced',
  highContrast: 'High contrast',
  dim: 'Dim reading',
  system: 'Follow system appearance',
};

export function Logo() {
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" aria-hidden="true" focusable="false">
      <circle cx="11" cy="11" r="9.5" fill="none" stroke="var(--accent)" strokeWidth="1.5" />
      <path d="M13.5 5.2a6 6 0 1 0 3.3 8.6A5 5 0 0 1 13.5 5.2z" fill="var(--accent)" />
    </svg>
  );
}

export function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button type="button" role="switch" className="switch" aria-checked={checked} aria-label={label} disabled={disabled} onClick={() => onChange(!checked)} />
  );
}

export function ThemeSelect({ value, onChange, id }: { value: ThemeId; onChange: (v: ThemeId) => void; id: string }) {
  return (
    <div className="field">
      <label htmlFor={id}>Theme</label>
      <select id={id} value={value} onChange={(e) => onChange(e.target.value as ThemeId)}>
        {THEME_IDS.map((t) => <option key={t} value={t}>{THEME_LABELS[t]}</option>)}
      </select>
    </div>
  );
}

/** Slider with local state so dragging is smooth; the change is committed (saved) after a short pause. */
export function Slider({ id, label, value, limit, onCommit }: { id: string; label: string; value: number; limit: { min: number; max: number; step: number }; onCommit: (v: number) => void }) {
  const [local, setLocal] = useState(value);
  useEffect(() => setLocal(value), [value]);
  useEffect(() => {
    if (local === value) return;
    const t = setTimeout(() => onCommit(local), 150);
    return () => clearTimeout(t);
  }, [local, value, onCommit]);
  return (
    <div className="field">
      <div className="row"><label htmlFor={id}>{label}</label><output htmlFor={id}>{local}%</output></div>
      <input id={id} type="range" min={limit.min} max={limit.max} step={limit.step} value={local} aria-valuetext={`${local} percent`} onChange={(e) => setLocal(Number(e.target.value))} />
    </div>
  );
}

export function AppearanceControls({ settings, onChange, showSepia }: { settings: Settings; onChange: (u: (s: Settings) => Settings, msg: string) => void; showSepia: boolean }) {
  return (
    <div className="stack">
      <ThemeSelect id={`theme-${showSepia ? 'o' : 'p'}`} value={settings.theme} onChange={(theme) => onChange((s) => ({ ...s, theme }), `Theme set to ${THEME_LABELS[theme]}.`)} />
      <Slider id={`brightness-${showSepia ? 'o' : 'p'}`} label="Brightness" value={settings.brightness} limit={LIMITS.brightness} onCommit={(brightness) => onChange((s) => ({ ...s, brightness }), `Brightness set to ${brightness}%.`)} />
      <Slider id={`contrast-${showSepia ? 'o' : 'p'}`} label="Contrast strength" value={settings.contrast} limit={LIMITS.contrast} onCommit={(contrast) => onChange((s) => ({ ...s, contrast }), `Contrast strength set to ${contrast}%.`)} />
      {showSepia && <Slider id="sepia-o" label="Warmth (sepia)" value={settings.sepia} limit={LIMITS.sepia} onCommit={(sepia) => onChange((s) => ({ ...s, sepia }), `Warmth set to ${sepia}%.`)} />}
    </div>
  );
}

export function StatusLine({ notice }: { notice: { kind: 'ok' | 'error'; text: string } | null }) {
  return (
    <div className={`status ${notice?.kind ?? ''}`} role={notice?.kind === 'error' ? 'alert' : 'status'} aria-live="polite">
      {notice ? `${notice.kind === 'ok' ? '✓ ' : '⚠ '}${notice.text}` : ''}
    </div>
  );
}
