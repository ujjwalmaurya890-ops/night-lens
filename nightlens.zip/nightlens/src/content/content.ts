import { ThemeEngine, type EngineStatus } from '../engine/engine';
import { buildTokens } from '../engine/palette';
import { decide } from '../shared/decision';
import { normalizeHostname } from '../shared/hostname';
import { STATUS_CHANGED, isGetStatusMessage, type StatusChangedMessage, type StatusPayload } from '../shared/messages';
import { loadSettings, subscribeToSettings } from '../shared/storage';
import { cloneDefaults } from '../shared/defaults';
import type { Settings, SiteStatus } from '../shared/types';

/** Site identity for rules: the top-level page's hostname when it can be determined (so iframes follow their page). */
export function getSiteHostname(loc: Location = location): string | null {
  try {
    const origins = (loc as Location & { ancestorOrigins?: ArrayLike<string> }).ancestorOrigins;
    if (origins && origins.length > 0) return normalizeHostname(new URL(origins[origins.length - 1]!).hostname);
  } catch { /* opaque origin: fall through */ }
  return normalizeHostname(loc.hostname);
}

export function startContentScript(): void {
  const w = window as unknown as { __nightlensLoaded?: boolean };
  if (w.__nightlensLoaded) return;
  w.__nightlensLoaded = true;

  const isTop = window.top === window;
  const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');
  let settings: Settings = cloneDefaults();
  let loaded = false;
  let siteStatus: SiteStatus = 'globally-off';
  let siteMode: StatusPayload['siteMode'] = null;

  const payload = (): StatusPayload => ({ hostname: getSiteHostname(), status: siteStatus, siteMode });

  const setStatus = (status: SiteStatus): void => {
    if (status === siteStatus) return;
    siteStatus = status;
    if (!isTop) return;
    const message: StatusChangedMessage = { type: STATUS_CHANGED, ...payload() };
    // Nobody may be listening (popup closed); that is not an error.
    chrome.runtime.sendMessage(message).catch(() => undefined);
  };

  const engine = new ThemeEngine(document, window, {
    onStatus: (s: EngineStatus) => setStatus(s === 'active' ? 'active' : 'native-dark'),
  });

  const apply = (): void => {
    if (!loaded) return;
    const decision = decide(settings, getSiteHostname(), darkQuery.matches);
    siteMode = decision.siteMode;
    if (!decision.active) {
      engine.stop();
      setStatus(decision.status);
      return;
    }
    const config = { tokens: buildTokens(settings), skipNativeDarkCheck: decision.forceNative };
    if (engine.isRunning) engine.update(config); else engine.start(config);
  };

  loadSettings().then((s) => { settings = s; loaded = true; apply(); });
  subscribeToSettings((s) => { settings = s; apply(); });
  darkQuery.addEventListener('change', apply);

  if (isTop) {
    chrome.runtime.onMessage.addListener((message: unknown, sender, sendResponse) => {
      if (sender.id !== chrome.runtime.id || !isGetStatusMessage(message)) return false;
      sendResponse(payload());
      return false;
    });
  }
}
