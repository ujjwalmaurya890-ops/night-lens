# NightLens

Readable dark mode for light websites. Chrome, Manifest V3, TypeScript, React (popup/settings only).

NightLens is **original work**. It takes inspiration from the general idea of tools like Dark Reader but shares no code, branding or artwork with them.

## Quick start

Requires **Node ≥ 22.12** (developed and tested on 22.22.2) and Chrome/Chromium.

```bash
npm install
npm run build          # -> dist/
# Chrome: chrome://extensions -> Developer mode -> Load unpacked -> select dist/
```

Full instructions: [docs/INSTALL.md](docs/INSTALL.md).

| Command | What it does |
|---|---|
| `npm run build` | Bundles popup/settings (Vite multi-page), content script and service worker (IIFE) into `dist/` |
| `npm run typecheck` | `tsc --noEmit` (strict) |
| `npm test` | 262 unit tests (Vitest + jsdom) |
| `npm run test:e2e` | Rebuilds, then 40 end-to-end tests: real Chromium with the built extension loaded (Playwright) |
| `npm run verify` | All of the above |

The e2e suite launches Chromium from `$NIGHTLENS_CHROMIUM` (default `/opt/pw-browsers/chromium-1194/chrome-linux/chrome`). Set it to your own Chrome/Chromium binary elsewhere.

## What it does

- **Theme engine** that reads each element's real computed colours and maps them (light→dark backgrounds, dark→light text, borders, links, form controls, SVG icons) instead of inverting the page. Contrast against the *actual* effective background is enforced per element.
- **Modes:** Balanced · High contrast · Dim reading · Follow system appearance. Plus brightness, contrast strength and warmth (sepia) sliders.
- **Per-site control:** exclude a site, or force it on when it already looks dark. Exact-hostname matching.
- **Safe by design:** images, video and audio are never altered; canvas charts keep their original backdrop; sites that already have a dark theme are detected and left alone; turning NightLens off restores the exact original DOM.
- **Private:** only the `storage` permission; no network access; nothing leaves your device. See [docs/SECURITY_AND_PRIVACY.md](docs/SECURITY_AND_PRIVACY.md).

Keyboard shortcut: **Alt+Shift+D** toggles NightLens (rebindable at `chrome://extensions/shortcuts`).

## Documentation

- [Architecture](docs/ARCHITECTURE.md)
- [Install, build, load, debug, update](docs/INSTALL.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)
- [Security, permissions and data stored](docs/SECURITY_AND_PRIVACY.md)
- [Feature ↔ implementation ↔ test matrix](docs/FEATURE_TEST_MATRIX.md)
- [Known limitations, unverified items, future work](docs/LIMITATIONS.md)
- [Manual browser test checklist for live sites](docs/BROWSER_TEST_CHECKLIST.md)
