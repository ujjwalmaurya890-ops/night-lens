# Manual browser test checklist (live sites)

The automated suite uses local fixtures only. Use this list on real sites with the extension loaded. **None of these live-site checks have been run by the author.** Record results in the table.

For every site: (a) first paint is not painfully bright, (b) all text readable, (c) links distinguishable from text, (d) focus ring visible with Tab, (e) images/video unchanged, (f) toggle via popup and Alt+Shift+D restores the exact original look, (g) no errors on `chrome://extensions` → Errors, (h) page still fully functional.

| # | Category | Things to try | Result |
|---|---|---|---|
| 1 | News & blogs | Article page, comments, sticky header, ad slots, paywall dialogs, embedded tweets/videos | |
| 2 | Documentation | Sidebar nav, code blocks with syntax colours, tables, admonition boxes, search box (⌘/Ctrl‑K), copy button | |
| 3 | Search engines | Query results, filters/tabs, autocomplete dropdown, "dark mode" setting interplay (site's own theme) | |
| 4 | E-commerce | Product grid, price/discount colours, size selectors, disabled "sold out" buttons, cart drawer/modal, image zoom | |
| 5 | Educational | Lesson text, quizzes (radio/checkbox), progress bars, canvas/SVG charts, embedded video | |
| 6 | Code hosting & code docs | File tree, diff view (added/removed lines remain distinguishable *without* relying on colour alone), syntax highlighting, README tables, issue labels | |
| 7 | Complex web apps | Dashboards, rich-text editors, spreadsheets, drag & drop, popovers/menus, toasts, tooltips, iframes, hover states (**known limitation**) | |
| 8 | Sites already dark | Confirm NightLens leaves them alone ("already looks dark"); try **Force dark** and **Back to automatic** | |

Extra: private/incognito (enable "Allow in Incognito" first), a site with strict CSP, a very long page (infinite scroll), a site that switches its own theme at runtime, windows at 200 % zoom, OS dark/light switching with "Follow system appearance".

Report anything that fails with the URL, the NightLens theme and sliders, and a screenshot.
