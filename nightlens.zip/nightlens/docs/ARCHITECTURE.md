# Architecture

## Components

```
            chrome.storage.local  ("nightlens:settings")
                 ▲        │ onChanged
   writes        │        ▼
 ┌──────────┐    │   ┌──────────────────────────────┐   status push / get-status
 │ Popup /  │────┘   │ Content script (every frame) │──────────────────────────────► Popup
 │ Options  │        │  decide() → ThemeEngine      │◄──── tabs.sendMessage(frameId:0)
 └──────────┘        └──────────────────────────────┘
 ┌──────────────────────┐
 │ Service worker       │  Alt+Shift+D toggles `enabled`; badge shows "OFF" when disabled
 └──────────────────────┘
```

- **Storage is the bus.** The popup, options page and service worker only *write* settings. Every content script listens to `chrome.storage.onChanged` and re-applies. There is no settings-push messaging to get out of sync.
- **Messages** are limited to: popup → top frame `get-status`, and top frame → popup `status-changed`. Both are validated (`src/shared/messages.ts`); the content script also checks `sender.id === chrome.runtime.id`; the popup checks `sender.tab.id` and `frameId === 0`.
- **The popup never needs the `tabs` permission.** `tab.url` is only available with `tabs` or host permissions (verified in Chrome's docs), so the popup asks the content script for the hostname instead.

## Source layout

```
src/
  manifest.json            MV3 manifest template (version injected from package.json at build)
  shared/                  types, defaults+limits, hostname rules, storage (+sanitising), messages, decide()
  engine/
    color.ts               parse (rgb/hex/hsl/oklab/oklch/lab/lch/color()), HSL, WCAG luminance/contrast, ensureContrast
    palette.ts             presets + slider settings → ThemeTokens
    mapper.ts              background / foreground / border / link colour mapping
    styles.ts              static base CSS (variables, selection, placeholder, focus ring, early-paint guard)
    detect.ts              "is this site already dark?" heuristic
    engine.ts              ThemeEngine: traversal, batching, observers, attribute+rule generation, restore
  content/                 bootstrap: settings → decision → engine; status messaging
  background/              service worker handlers (+ thin registration file)
  popup/  options/  ui/    React UI, shared components/hooks, design tokens (ui.css)
scripts/                   build.mjs (Vite JS API), make-icons.mjs (original icons, no dependencies)
tests/unit/                Vitest (jsdom) · tests/e2e/ Playwright + local fixture sites
```

## How theming works

The engine never changes a page's own stylesheets or inline styles. For each element it:

1. **Reads** the computed `background-color`, `color`, border colours (per side), `background-image`, disabled state, etc.
2. **Maps** them through the active theme (`mapper.ts`), then guarantees contrast (`ensureContrast`) against the element's *effective* background (the nearest mapped ancestor backgrounds, alpha-blended).
3. **Writes** only `data-nl-*` attributes whose values are colour keys, e.g. `data-nl-bg="1b1d21"`, plus one generated rule per distinct colour: `[data-nl-bg="1b1d21"]{background-color:#1b1d21 !important}`.

Consequences of this design:

- **Exact restoration.** Disabling removes the attributes and both `<style>` elements; a unit test asserts the DOM's `outerHTML` is identical before and after.
- **Computed-style based, so cross-origin stylesheets work.** The engine never parses site CSS (which `document.styleSheets` can't read cross-origin).
- **Works under strict CSP**, verified e2e with `style-src 'self'` (extension-injected styles are not subject to the page's CSP).
- **No MutationObserver feedback loop.** The engine only writes `data-nl-*` attributes, which its observers do not watch; verified by a quiescence test in jsdom and in real Chromium.

### Passes and batching

`strip → read → write` per batch of ≤400 elements, scheduled with `requestAnimationFrame`: all reads of a batch share one style recalculation, then all writes. Queue is a `Set` (dedup). A `WeakSet` records processed elements so re-processing happens only when something changed.

### Dynamic content

One `MutationObserver` (childList + `class` + `style` attributes, subtree) per root (document and each open shadow root):

- Added nodes → enqueue subtree (SPAs, infinite scroll).
- `class` change → re-read that element and (if ≤2000 descendants) its subtree.
- `style` change → re-read **only if** the attribute text mentions colour/background/border/fill/stroke (animation churn on `transform`/`width` is ignored).
- `<html>`/`<body>` class/`data-theme`/`style` changes (site's own theme switch) → debounced re-evaluation of native-dark detection and a full rescan.
- Stylesheet `<link>` `load` events and `window.load` → debounced full rescan, because late CSS changes computed colours.

### Special content

| Content | Handling |
|---|---|
| `img`, `picture`, `video`, `audio`, `iframe`, `object`, `embed` | Never touched, never walked. Dim theme applies a low-specificity `brightness(0.88)` to img/video/picture only. |
| Elements with `background-image`/gradient or an unparsable colour | "Locked": colours left as authored, and descendants' text is left alone too (the author chose it for that backdrop). |
| `<canvas>` ≥100×60 on a light original backdrop; `<svg>` charts (≥100×60 containing `<text>`) | Placed on their original backdrop colour ("plate"), pixels untouched. |
| Small inline SVG icons (≤64px) | Shape `fill`/`stroke` recoloured with ≥3:1 contrast. Large illustrations untouched. |
| Open shadow roots | Own `<style>` pair injected and observed. Closed roots are not reachable. |
| Native `<select>`/scrollbars/UA form controls | `color-scheme: dark` on `:root`. |
| Sites with their own dark theme | Detected with NightLens styles detached; left alone. "Force on" overrides. |

### Original-style restoration

`stop()` removes observers/listeners/timers, strips every managed attribute from every themed root, removes all injected `<style>` elements, and resets internal maps.
