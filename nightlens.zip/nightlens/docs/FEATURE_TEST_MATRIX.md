# Feature ↔ implementation ↔ test

**Legend.** U = unit test (Vitest/jsdom, `tests/unit`), E = end-to-end test (real Chromium 141 + the built extension, `tests/e2e/extension.spec.ts`), ✔ = verified by an automated test that was run and passed (262 unit, 40 e2e on 2026‑11‑01), ◐ = partially verified (see note), ✘ = not verified / not implemented.

## Theme engine (spec §3)

| Requirement | Implementation | Verification |
|---|---|---|
| Detect light styles, coordinated dark palette | `engine/mapper.ts`, `palette.ts` | ✔ U `theme.test.ts` (mapping); ✔ E every category page audited |
| Text/links/buttons/borders/forms/shadows/focus | `engine.ts` write(), `styles.ts` | ✔ U `engine.test.ts` (borders, disabled, links); ✔ E link/focus/placeholder test. Shadows are left as authored. |
| Nested/inherited styles | effective-background chain (`bgInfo`) | ✔ U + E contrast audits include nested text |
| Dynamic content (infinite scroll, SPA) | MutationObserver, batching | ✔ U dynamic tests; ✔ E webapp add-item, SPA route + 300-row bulk insert |
| Avoid re-processing | queue `Set`, `WeakSet`, style-churn filter | ✔ U "ignores style-attribute churn" (no `getComputedStyle` calls) |
| Efficient observation + cleanup | `stop()`, listener/timer teardown | ✔ U repeated enable/disable; ✔ E toggling live |
| No layout thrash / flicker | strip→read→write batches, early-paint guard | ◐ Batching by design; 7,500 elements themed in 624–794 ms measured in this sandbox (E). **Flicker not measured.** |
| Restore original appearance | attribute + style removal | ✔ U `outerHTML` identical after stop; ✔ E computed colours identical after disable |
| Modern colour syntax (oklch/lab/p3/color-mix) | `engine/color.ts` | ✔ U reference-value tests; ✔ E `modern.html` |

## Readability & accessibility (§4)

| Requirement | Verification |
|---|---|
| Palette: charcoal bg, soft-white text, muted, link, border, focus, selection | ✔ U `theme.test.ts` (all 4 themes × slider extremes: text/muted/link/visited ≥ min, focus ≥ 3:1, border ≥ min, selection ≥ 4.5) |
| ≥4.5:1 normal text (7:1 High contrast) | ✔ E in-page audit of every visible text node on 8 fixture pages + dim/HC/slider extremes. Audit skips author-controlled image/gradient backgrounds (documented). |
| Hover / focus / disabled / selected / visited states | focus ✔ E (2px outline on all popup stops; page focus ring); disabled ✔ U (≥3:1); visited ✔ U (rule present, link marking) — real visited rendering ✘ not verified; **hover ✘ KNOWN LIMITATION (suppressed), E documents it** |
| Not colour alone | Popup/options status text has words + glyphs; page error/success text is the site's own. ✔ UI by inspection; ✘ no automated test beyond text presence |
| Keyboard nav & visible focus | ✔ E tab order of all 7 popup stops + Space toggles switch |
| Reduced motion | ✔ U CSS contains `prefers-reduced-motion`; NightLens adds no animation to pages |
| Don't shrink text/override sizes | Engine only writes colour properties ✔ by construction (rules list in `engine.ts`) |
| Programmatic contrast, no unfounded WCAG claim | ✔ `color.ts` + tests; **No claim of full WCAG conformance is made.** Screen readers (NVDA/JAWS/VoiceOver) were **not** tested. |

## Special content (§5)

| Item | Status | Evidence |
|---|---|---|
| Images/photos | ✔ | E: no attrs, `filter: none` |
| SVG icons | ✔ | U + E icon fill changed; large illustrations untouched (U) |
| Logos | ◐ never altered; dark transparent logos may be low-contrast (limitation) | — |
| Video & controls | ✔ untouched | E, U |
| Canvas, charts | ✔ original backdrop plate; pixels untouched | U + E (pixel read-back) |
| Syntax highlighting | ✔ colours mapped and audited | E `docs`, `codehost` |
| Code/text editors (Monaco/CodeMirror) | ✘ not tested | — |
| PDF viewers | ✘ not supported (Chrome's viewer is an extension page) | — |
| Tables/spreadsheets | ✔ tables | E `docs` (zebra rows, headers). Canvas spreadsheets not tested. |
| Search boxes, forms | ✔ | E `search`, `shop` |
| Dropdowns/popovers | ✔ custom menu; ◐ native `<select>` popup relies on `color-scheme: dark`, not screenshot-verified | E `webapp` |
| Modal dialogs | ✔ `<dialog open>` | E `webapp` |
| Iframes | ✔ same-origin + cross-origin (own engine per frame, follows top-site rules); sandboxed/`about:blank` frames not covered | E |
| Sites with native dark | ✔ detection + force-on override | U + E |

## User features (§6)

| Feature | Implementation | Verification |
|---|---|---|
| Global enable/disable | popup/options switch, shortcut | ✔ U popup, background; ✔ E popup toggles live page |
| Default theme | `theme` setting | ✔ U, E |
| Brightness / contrast / warmth | sliders → `buildTokens` | ✔ U (tokens), E (extremes); warmth in Settings page only ✔ U |
| Reset to defaults (confirmed) | popup + options | ✔ U + E |
| Per-site on/off, excluded list, persistence | popup site switch, options list, `siteRules` | ✔ U (storage, hostname, decide, options page); ✔ E live add/remove |
| Exact hostname matching, documented | `hostname.ts`, Options text, this doc | ✔ U; ✔ E (`127.0.0.1` excluded, `localhost` themed) |
| Modes: balanced / high contrast / dim / follow system | `palette.ts`, `decision.ts` | ✔ U + E (`emulateMedia`) |
| Keyboard shortcut | `commands` + `handleCommand` | ✔ E: registered with Chrome as Alt+Shift+D; ✔ U handler; **✘ a physical key press was not exercised** |
| Quick popup, clear status messages | `popup/`, aria-live region, badge "OFF" | ✔ U + E (messages); badge ✔ U (API call) — not visually verified |
| No fake controls | every control has a test that checks its effect | ✔ |

## Architecture/quality, security, performance (§8, §11)

| Requirement | Verification |
|---|---|
| TypeScript strict, explicit types | ✔ `npm run typecheck` (strict, noUnused*) |
| Least privilege, no remote code, no network | ✔ manifest inspected; grep evidence in SECURITY doc |
| Message validation | ✔ U `shared.test.ts`, `popup.test.tsx` (other tab/iframe ignored) |
| Invalid/missing settings, storage errors | ✔ U (sanitise, get/set failure surfaced in UI) |
| No MutationObserver feedback loop | ✔ U + E quiescence tests (0 mutations after settling) |
| Debounce/batch | ✔ U time-slicing test; ✔ E 7.5k-element measurement |
| Strict CSP pages | ✔ E |
| Console/uncaught errors | ✔ E error-hygiene test (service worker, popup, options, themed page) |
