# Security, permissions and data

## Permissions (from the built `dist/manifest.json`)

| Entry | Why | Not requested |
|---|---|---|
| `permissions: ["storage"]` | Save settings in `chrome.storage.local`. | `tabs`, `activeTab`, `scripting`, `webRequest`, `history`, `cookies`, any `host_permissions` |
| `content_scripts.matches: http://*/*, https://*/*` | The theme must run automatically on every site you visit. Chrome shows this as access to "read and change your data on all websites"; that is inherent to an always-on page-restyling extension. | `file://`, `about:blank`, `chrome://` (not matched) |
| `commands.toggle-nightlens` (Alt+Shift+D) | Keyboard toggle. | — |

Default MV3 extension-page CSP is kept (no `unsafe-eval`, no remote scripts). No `web_accessible_resources`, no `externally_connectable`: web pages cannot message the extension.

## What the code does and does not do

Checked by `grep` over `src/` (zero matches): `fetch(`, `XMLHttpRequest`, `WebSocket`, `sendBeacon`, `eval(`, `new Function`, `innerHTML`, `document.write`, `importScripts`, `localStorage`, `sessionStorage`, `indexedDB`. In the built files: `content.js` contains one URL-shaped string (the SVG XML namespace) and `background.js` none; neither contains `fetch(`, `XMLHttpRequest`, `WebSocket`, `sendBeacon`, `eval(` or `new Function` (grep-verified on the final build). The popup/options bundle (React) contains XML namespace constants and the text `https://react.dev/errors/` that React embeds in its production error messages; these are strings, not requests, and the e2e suite never observed extension pages making network requests (not instrumented beyond console errors, so treat this as code-inspection evidence, not a packet capture).

- **No page content leaves the browser.** The content script reads computed colours of elements to choose replacements. Those values are used in memory and never stored or sent.
- **No browsing history.** The only hostnames stored are ones **you** add (exclude/force on).
- **No analytics, telemetry or remote config.**
- **Message validation.** Content script accepts only `get-status` from its own extension (`sender.id`); popup accepts only well-formed `status-changed` from the active tab's top frame. Payloads are schema-checked (hostnames re-validated).
- **Settings are sanitised on every read and write** (`sanitizeSettings`): types, ranges, theme IDs, hostnames (strict regex; keys like `__proto__` are rejected), at most 2000 rules. Corrupt storage falls back to defaults instead of throwing.
- **Injected styling is inert data:** generated rules only contain colour keys matching `[0-9a-f]{6,8}` that the engine itself produced. No page text is ever inserted into CSS or HTML. UI uses React (escaped) and the code has no `innerHTML`.
- **Page scripts can't reach the extension** (isolated world), but they *can* see the `data-nl-*` attributes and `<style data-nl-owned>` elements NightLens adds to the DOM. These contain only colour values.

## Data stored (`chrome.storage.local`, key `nightlens:settings`)

```json
{ "schemaVersion": 1, "enabled": true, "theme": "balanced",
  "brightness": 100, "contrast": 100, "sepia": 0,
  "siteRules": { "example.com": "off", "dark.example.org": "on" } }
```

Local to the browser profile; not synced (`storage.sync` is deliberately not used). Removed when the extension is uninstalled. The Settings page has a one-click (confirmed) reset that restores defaults and clears all site rules.

## Residual risks

- Because the extension runs on all sites, a compromised build or dependency could in principle read page content. Mitigations: tiny dependency set (React only at runtime, used only in popup/options; the content script bundle imports none), pinned versions, no remote code. A formal supply-chain audit and `npm audit` review were **not** performed.
- Sites can detect NightLens via the `data-nl-*` attributes.
