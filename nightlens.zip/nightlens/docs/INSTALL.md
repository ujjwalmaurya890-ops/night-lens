# Install, build, load, debug, update

## 1. Install dependencies

Requirements: **Node ≥ 22.12** (Vitest 5 requires it; Vite 8 needs ^20.19 or ≥22.12), npm, Chrome/Chromium.

```bash
npm install
```

Exact versions are pinned in `package.json` and were checked against the npm registry on 2026‑11‑01:
`vite 8.3.5`, `vitest 5.0.5`, `typescript 7.0.2`, `react/react-dom 19.3.1`, `@vitejs/plugin-react 6.1.2`, `@types/chrome 0.3.6`, `@types/node 22.19.1`, `jsdom 30.1.3`, `@testing-library/react 16.3.3`, `@playwright/test 1.64.1`.

## 2. Build

```bash
npm run build
```

Produces `dist/` (`manifest.json`, `background.js`, `content.js`, `popup/`, `options/`, `assets/`, `icons/`).

## 3. Load in Chrome

1. Open `chrome://extensions`.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose the **`dist`** folder (not the project root).
4. Pin NightLens from the puzzle-piece menu. Open any `http(s)` page.

## 4. Debug

| Surface | How |
|---|---|
| Popup | Right-click the toolbar icon → **Inspect popup**. (Tip: open `chrome-extension://<id>/popup/index.html?tab=<tabId>` in a normal tab to keep it open; `?tab=` is a documented debugging aid.) |
| Settings page | Open it, press F12. |
| Service worker | `chrome://extensions` → NightLens → **service worker** link. |
| Content script | On a page: DevTools → Console → choose the NightLens context in the "top" dropdown; or Sources → Content scripts. Themed elements carry `data-nl-*` attributes; our styles are `<style data-nl-owned>`. |
| Errors | `chrome://extensions` → NightLens → **Errors** button. |

## 5. Update after code changes

```bash
npm run build
```

Then `chrome://extensions` → NightLens → **reload** (↻). **Reload any open tabs**: pages that were open keep running the *old* content script, which cannot talk to the reloaded extension. Popups and the service worker pick up changes immediately after the reload.

## 6. Tests

```bash
npm run typecheck
npm test              # unit
npm run test:e2e      # rebuilds, then runs real Chromium + extension
# Use another browser binary for e2e:
NIGHTLENS_CHROMIUM=/path/to/chrome npm run test:e2e
```
