# Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| Popup says "NightLens can't run on this page" | `chrome://`, the Chrome Web Store, `file://` URLs, PDF viewer and other extension pages cannot be themed. If it's a normal site, you opened the tab before installing/updating: **reload the tab**. |
| Nothing changes after rebuilding | You must click **reload** on `chrome://extensions` *and* reload open tabs (see INSTALL.md §5). Also check you loaded `dist/`, not the project root. |
| Site looks unchanged and popup says "already looks dark" | Native-dark detection judged the page's own background dark. Use **Force dark mode on this site** in the popup if you disagree. |
| Site is dark but part of it is a bright block | That area uses a background image/gradient (left as authored), or it's a chart/canvas kept on its original backdrop on purpose. Exclude the site if it bothers you. |
| Dark text on dark logo/icon | Logos/photos are never recoloured. Dark transparent logos can be hard to see on a dark page. Exclude the site (known limitation). |
| Hover highlights on buttons/menus don't change | Known limitation: recoloured elements ignore the site's `:hover` background. |
| Slight light flash when a page starts loading | Settings load asynchronously at `document_start`. Not measured; see LIMITATIONS. |
| Shortcut doesn't work | Another extension/browser feature may own Alt+Shift+D. Set it at `chrome://extensions/shortcuts`. |
| "Could not save settings: …" in the popup | `chrome.storage.local` rejected the write (e.g. quota). The message shows the real error; nothing was saved. |
| A site rule for `example.com` doesn't affect `www.example.com` | By design: exact hostname matching. Add each hostname. |
| `npm run test:e2e` can't launch a browser | Set `NIGHTLENS_CHROMIUM` to a full Chrome/Chromium binary (extensions need a full build, not headless-shell). |
| Build fails on Node 20 | Vitest 5 needs Node ≥ 22.12 (the build itself needs only Vite's ^20.19). |
