# Known limitations, unverified items, future work

## Known limitations (measured or by design)

1. **Site `:hover` backgrounds are suppressed** on elements NightLens recolours (measured: computed background identical before/during hover; pinned by an e2e test). Overrides use `!important` attribute rules, which beat the site's hover rule. Non-colour hover effects (cursor, transform, shadows) are not touched by the engine, but were not individually tested.
2. **Image/gradient backgrounds are left as authored** (and their text too). Light gradients remain light "islands". Dark hero images with light text are fine.
3. **Logos and photos are never changed.** Dark transparent logos can be unreadable on dark pages. Use per-site exclusion.
4. **Canvas/SVG charts are shown on their original light backdrop** so their pixels stay readable. This yields bright rectangles in an otherwise dark page by design. Transparent decorative canvases on light pages also get a light plate.
5. **Elevation order is inverted** for light-on-light layouts: a white card on a light-grey page becomes slightly *darker* than the page.
6. **Inline `style="… !important"`** colours may defeat the override (inline `!important` beats stylesheet `!important`). Untested.
7. **Closed shadow roots** cannot be reached; open ones are handled (jsdom-tested only, not in a real component library).
8. **Unsupported pages:** `chrome://`, Web Store, `file://`, PDF viewer, extension pages, `about:blank`/`srcdoc` frames.
9. **Native-dark detection is a heuristic** (page `body`/`html` background luminance < 0.2, or `color-scheme`). Pages whose dark theme lives in a wrapper element may be themed unnecessarily (harmless: dark stays dark) or occasionally missed; use Force/Exclude.
10. **Contrast guarantees are per element against the engine's idea of its effective background.** Not guaranteed over images/gradients (author-controlled), text with `background-clip:text`, or colours Chrome returns in a form the parser doesn't know (those elements are left alone).
11. **Contrast floors may be unreachable on mid-tone backgrounds** (e.g. 7:1 for High contrast on a mid-grey); the engine then falls back to white/black, which is the best possible.
12. **Settings storage is read-modify-write**, last write wins when two surfaces save at the exact same moment.
13. **Reloaded/updated extension:** already-open tabs keep an orphaned old content script until reloaded.

## Not verified (no evidence gathered)

- Any **live website**. All tests use local fixture pages written for this project; no claim of universal compatibility.
- **Browsers other than Chromium 141** (Chrome stable, Edge, Brave, Firefox, Safari). Firefox support was deliberately not attempted: it needs separate verification of Manifest V3 differences, and the task said to add it only after verification.
- A **physical Alt+Shift+D key press** (registration verified, handler unit-tested).
- **First-paint flash** at `document_start` (settings load asynchronously). Not measured. Mitigation: the early-paint guard rule paints `<html>` dark as soon as the engine starts.
- **Memory use, battery, very large/long-lived pages**, CPU profiles. Only one throughput measurement (7,500 nodes ≈ 0.6–0.8 s in a container).
- **Screen readers**, high-contrast OS mode, zoom/DPI variations, RTL pages, print styles.
- Monaco/CodeMirror/Google-Docs-style apps, WebGL, `<video>` overlays, Shadow-DOM-heavy frameworks.
- `npm audit` / dependency vulnerability review.
- The `visited` link colour as actually painted (rule exists; Chrome restricts reading visited styles, so it can't be asserted from script).

## Future improvements (prioritised)

1. **Hover/active/focus-state preservation:** parse same-origin stylesheets (and fetch cross-origin ones via a `host_permissions` request) to remap colours inside pseudo-class rules instead of overriding elements.
2. **Logo handling:** heuristic or user "invert this image" per element for dark-on-transparent logos (sampling needs same-origin pixels).
3. **Early-paint cache:** cache the "enabled & theme" decision per origin to avoid any flash, without touching page storage.
4. **Gradient remapping** for light gradients.
5. **Import/export of settings**, per-site brightness/contrast overrides, wildcard subdomain rules (opt-in, documented).
6. **Firefox/Edge builds** after verifying each platform's current requirements.
7. Larger real-world compatibility corpus in CI (recorded pages), visual regression snapshots, accessibility audit with axe-core and screen readers.
8. Pause-on-idle for the observer, per-frame opt-out for performance-sensitive apps.
